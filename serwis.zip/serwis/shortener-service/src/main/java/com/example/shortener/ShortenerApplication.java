package com.example.shortener;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Skanujemy oba pakiety, ale konfiguracja Cassandry jest już w osobnej klasie
@SpringBootApplication(scanBasePackages = {"com.example.shortener", "com.example.common"})
public class ShortenerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShortenerApplication.class, args);
    }
}
