package com.example.redirect;

import com.example.common.UrlMapping;
import com.example.common.UrlRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.time.Instant;
import java.util.Optional;

@RestController
public class RedirectController {

    // Dodajemy logger, aby widzieć w logach, co się dzieje
    private static final Logger log = LoggerFactory.getLogger(RedirectController.class);

    @Autowired
    private UrlRepository repository;

    @GetMapping("/{shortCode}")
    public ResponseEntity<String> redirect(@PathVariable String shortCode) {
        log.info("Otrzymano żądanie przekierowania dla kodu: {}", shortCode);

        try {
            Optional<UrlMapping> mappingOptional = repository.findById(shortCode);

            // Poprawna obsługa przypadku, gdy nic nie znaleziono
            if (mappingOptional.isEmpty()) {
                log.warn("Nie znaleziono kodu w bazie: {}", shortCode);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Short URL not found");
            }

            UrlMapping mapping = mappingOptional.get();

            // Sprawdzamy, czy link nie wygasł (zabezpieczenie przed NullPointerException)
            if (mapping.getCreatedAt() == null || mapping.getLongUrl() == null) {
                log.error("Krytyczny błąd: dane w bazie są niekompletne dla kodu {}", shortCode);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Corrupted data in database.");
            }
            Instant expiry = mapping.getCreatedAt().plusSeconds(mapping.getTtlDays() * 86400L);
            if (Instant.now().isAfter(expiry)) {
                log.warn("Link wygasł: {}", shortCode);
                // Usuwamy wygaśnięty link
                repository.delete(mapping);
                return ResponseEntity.status(HttpStatus.GONE).body("URL has expired");
            }

            // Aktualizujemy datę ostatniego użycia
            mapping.setLastAccessedAt(Instant.now());
            repository.save(mapping);
            log.info("Znaleziono link. Przekierowuję na: {}", mapping.getLongUrl());

            // Tworzymy i zwracamy poprawną odpowiedź HTTP 302 (Found)
            HttpHeaders headers = new HttpHeaders();
            headers.setLocation(URI.create(mapping.getLongUrl()));
            return new ResponseEntity<>(headers, HttpStatus.FOUND);

        } catch (Exception e) {
            // TO JEST NAJWAŻNIEJSZY FRAGMENT!
            // Jeśli cokolwiek innego pójdzie nie tak, łapiemy błąd i go logujemy.
            log.error("KRYTYCZNY BŁĄD podczas przekierowania dla kodu: {}", shortCode, e);

            // Zwracamy grzeczną odpowiedź 500, zamiast pozwalać aplikacji umrzeć.
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An unexpected error occurred.");
        }
    }
}
